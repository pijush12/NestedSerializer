
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from rest_framework.parsers import JSONParser
from django.http.response import JsonResponse
from basics.models import Song, Singer
from basics.serializers import SongSerializer, SingerSerializer
from rest_framework.decorators import api_view
from rest_framework.response import Response

@csrf_exempt
@api_view(['GET','POST','PUT','DELETE'])
def SongViewSet(request,id=None):
    if request.method=='GET':
        if id is not None:
            students=Song.objects.get(id=id)
            student_serializer=SongSerializer(students)
            return Response(student_serializer.data)
            #return JsonResponse(student_serializer.data,safe=False)
        else:
            students=Song.objects.all()
            student_serializer=SongSerializer(students,many=True)
            return Response(student_serializer.data)
            #return JsonResponse(student_serializer.data,safe=False)    

        
    elif request.method=='POST':
        student_data=JSONParser().parse(request)
        student_serializer=SongSerializer(data=student_data)
        if student_serializer.is_valid():
            student_serializer.save()
            #return JsonResponse("Added Sucessfully",safe=False)
            return Response("Added sucessfully")
        #return JsonResponse("Failed to add",safe=False)
        return Response("Failed to add")
    elif request.method=='PUT':
        student_data=JSONParser().parse(request)
        student=Song.objects.get(id=student_data['id'])
        student_serializer=SongSerializer(student,data=student_data)
        if student_serializer.is_valid():
            student_serializer.save()
            #return JsonResponse('Updated Sucessfully',safe=False)
            return Response("Updated Sucessfully")
        #return JsonResponse("Failed to update")
        return Response("Failed to update")
    elif request.method=='DELETE':
        student=Song.objects.get(id=id)
        student.delete()
        #return JsonResponse("Deleted Sucessfully", safe=False)
        return Response("Deleted sucessfully")   



@csrf_exempt
@api_view(['GET','POST','PUT','DELETE'])
def SingerViewSet(request,id=None):
    if request.method=='GET':
        if id is not None:
            students=Singer.objects.get(id=id)
            student_serializer=SingerSerializer(students)
            return Response(student_serializer.data)
            #return JsonResponse(student_serializer.data,safe=False)
        else:
            students=Singer.objects.all()
            student_serializer=SingerSerializer(students,many=True)
            return Response(student_serializer.data)
            #return JsonResponse(student_serializer.data,safe=False)    

        
    elif request.method=='POST':
        student_data=JSONParser().parse(request)
        student_serializer=SingerSerializer(data=student_data)
        if student_serializer.is_valid():
            student_serializer.save()
            #return JsonResponse("Added Sucessfully",safe=False)
            return Response("Added sucessfully")
        #return JsonResponse("Failed to add",safe=False)
        return Response("Failed to add")
    elif request.method=='PUT':
        student_data=JSONParser().parse(request)
        student=Singer.objects.get(id=student_data['id'])
        student_serializer=SingerSerializer(student,data=student_data)
        if student_serializer.is_valid():
            student_serializer.save()
            #return JsonResponse('Updated Sucessfully',safe=False)
            return Response("Updated Sucessfully")
        #return JsonResponse("Failed to update")
        return Response("Failed to update")
    elif request.method=='DELETE':
        student=Singer.objects.get(id=id)
        student.delete()
        #return JsonResponse("Deleted Sucessfully", safe=False)
        return Response("Deleted sucessfully")   

